# Rotación forzada (Android)

App que fuerza la orientación de la pantalla en **todas** las apps usando una ventana
invisible (overlay) mantenida por un servicio en primer plano.

## Cómo abrirla
1. Abre la carpeta `ForceRotate` en **Android Studio** (Koala o más nuevo).
2. Deja que sincronice Gradle (te ofrecerá generar el wrapper si falta).
3. Conecta tu teléfono (depuración USB activada) y pulsa **Run**.

## Cómo usarla
1. Pulsa **Dar permiso de superposición** y activa "Mostrar sobre otras apps" para la app.
2. Elige Vertical / Horizontal / Vertical invertido / Horizontal invertido.
3. Cambia rápido desde los botones de la notificación (Vertical, Horizontal, Auto, Detener).
4. **Automático** o **Detener** devuelven el comportamiento normal.

## Cómo funciona
`RotationService` agrega una vista de 0×0 con `TYPE_APPLICATION_OVERLAY` y le asigna
`screenOrientation`. Mientras esa ventana exista, Android respeta esa orientación.

## Notas
- Android 13+ pide permiso de notificaciones (necesario para mostrar los botones).
- En algunos teléfonos (Xiaomi, Huawei, Samsung) conviene desactivar la optimización de
  batería para la app, o el sistema puede cerrar el servicio.
- minSdk 26 (Android 8.0), targetSdk 34.
