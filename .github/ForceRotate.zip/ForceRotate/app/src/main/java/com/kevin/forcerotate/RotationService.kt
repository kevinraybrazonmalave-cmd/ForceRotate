package com.kevin.forcerotate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Servicio en primer plano que mantiene una ventana invisible (overlay)
 * con screenOrientation fijo. Mientras la ventana exista, Android obedece
 * esa orientación en cualquier app.
 */
class RotationService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val orientation = intent?.getIntExtra(EXTRA_ORIENTATION, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }
            ?: loadOrientation()

        startAsForeground(orientation)
        applyOrientation(orientation)
        saveState(orientation, running = true)
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        saveState(loadOrientation(), running = false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- Overlay ----------

    private fun applyOrientation(orientation: Int) {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            screenOrientation = orientation
        }

        val existing = overlayView
        if (existing == null) {
            val view = View(this)
            windowManager.addView(view, params)
            overlayView = view
        } else {
            windowManager.updateViewLayout(existing, params)
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: IllegalArgumentException) {
                // ya había sido removida
            }
        }
        overlayView = null
    }

    // ---------- Notificación ----------

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun startAsForeground(orientation: Int) {
        val notification = buildNotification(orientation)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(current: Int): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        fun action(label: String, orientation: Int, code: Int): Notification.Action {
            val intent = Intent(this, RotationService::class.java)
                .setAction(ACTION_SET)
                .putExtra(EXTRA_ORIENTATION, orientation)
            val pi = PendingIntent.getService(
                this, code, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(null, label, pi).build()
        }

        val stopIntent = PendingIntent.getService(
            this, 99,
            Intent(this, RotationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text, orientationLabel(this, current)))
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(action(getString(R.string.btn_vertical_short), ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, 1))
            .addAction(action(getString(R.string.btn_horizontal_short), ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, 2))
            .addAction(action(getString(R.string.btn_auto_short), ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR, 3))
            .addAction(Notification.Action.Builder(null, getString(R.string.btn_stop_short), stopIntent).build())
            .build()
    }

    // ---------- Estado ----------

    private fun saveState(orientation: Int, running: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putInt(KEY_ORIENTATION, orientation)
            .putBoolean(KEY_RUNNING, running)
            .apply()
    }

    private fun loadOrientation(): Int =
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .getInt(KEY_ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR)

    companion object {
        const val ACTION_SET = "com.kevin.forcerotate.SET"
        const val ACTION_STOP = "com.kevin.forcerotate.STOP"
        const val EXTRA_ORIENTATION = "orientation"

        const val PREFS = "forcerotate"
        const val KEY_ORIENTATION = "orientation"
        const val KEY_RUNNING = "running"

        private const val CHANNEL_ID = "force_rotate"
        private const val NOTIFICATION_ID = 1

        fun orientationLabel(context: Context, orientation: Int): String = context.getString(
            when (orientation) {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT -> R.string.btn_vertical
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE -> R.string.btn_horizontal
                ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT -> R.string.btn_vertical_inv
                ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE -> R.string.btn_horizontal_inv
                else -> R.string.btn_auto
            }
        )
    }
}
