package com.kevin.forcerotate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)

        bind(R.id.btnVertical, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
        bind(R.id.btnHorizontal, ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
        bind(R.id.btnVerticalInv, ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT)
        bind(R.id.btnHorizontalInv, ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE)
        bind(R.id.btnAuto, ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, RotationService::class.java).setAction(RotationService.ACTION_STOP)
            )
            status.postDelayed({ refreshStatus() }, 300)
        }

        findViewById<Button>(R.id.btnPermission).setOnClickListener { requestOverlayPermission() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun bind(buttonId: Int, orientation: Int) {
        findViewById<Button>(buttonId).setOnClickListener { force(orientation) }
    }

    private fun force(orientation: Int) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_permission, Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, RotationService::class.java)
            .setAction(RotationService.ACTION_SET)
            .putExtra(RotationService.EXTRA_ORIENTATION, orientation)
        startForegroundService(intent)
        status.postDelayed({ refreshStatus() }, 300)
    }

    private fun requestOverlayPermission() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(RotationService.PREFS, MODE_PRIVATE)
        val running = prefs.getBoolean(RotationService.KEY_RUNNING, false)
        val orientation = prefs.getInt(
            RotationService.KEY_ORIENTATION,
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        )

        val permissionText = if (Settings.canDrawOverlays(this))
            getString(R.string.permission_ok) else getString(R.string.permission_missing)

        val stateText = if (running)
            getString(R.string.state_active, RotationService.orientationLabel(this, orientation))
        else getString(R.string.state_inactive)

        status.text = "$permissionText\n$stateText"
    }
}
